Sound pack downloaded from Freesound.org
----------------------------------------

This pack of sounds contains sounds by stamperadam ( http://www.freesound.org/people/stamperadam/  )
You can find this pack online at: http://www.freesound.org/people/stamperadam/packs/6168/


License details
---------------

Sampling+: http://creativecommons.org/licenses/sampling+/1.0/
Creative Commons 0: http://creativecommons.org/publicdomain/zero/1.0/
Attribution: http://creativecommons.org/licenses/by/3.0/
Attribution Noncommercial: http://creativecommons.org/licenses/by-nc/3.0/


Sounds in this pack
-------------------

  * 96114__stamperadam__G_5_soft.wav
    * url: http://www.freesound.org/people/stamperadam/sounds/96114/
    * license: Creative Commons 0
  * 96113__stamperadam__G_5_med.wav
    * url: http://www.freesound.org/people/stamperadam/sounds/96113/
    * license: Creative Commons 0
  * 96112__stamperadam__G_5_hard.wav
    * url: http://www.freesound.org/people/stamperadam/sounds/96112/
    * license: Creative Commons 0
  * 96111__stamperadam__G_4_soft.wav
    * url: http://www.freesound.org/people/stamperadam/sounds/96111/
    * license: Creative Commons 0
  * 96110__stamperadam__G_4_med.wav
    * url: http://www.freesound.org/people/stamperadam/sounds/96110/
    * license: Creative Commons 0
  * 96109__stamperadam__G_4_hard.wav
    * url: http://www.freesound.org/people/stamperadam/sounds/96109/
    * license: Creative Commons 0
  * 96108__stamperadam__G_3_soft.wav
    * url: http://www.freesound.org/people/stamperadam/sounds/96108/
    * license: Creative Commons 0
  * 96107__stamperadam__G_3_med.wav
    * url: http://www.freesound.org/people/stamperadam/sounds/96107/
    * license: Creative Commons 0
  * 96106__stamperadam__G_3_hard.wav
    * url: http://www.freesound.org/people/stamperadam/sounds/96106/
    * license: Creative Commons 0
  * 96105__stamperadam__G_2_soft.wav
    * url: http://www.freesound.org/people/stamperadam/sounds/96105/
    * license: Creative Commons 0
  * 96104__stamperadam__G_2_med.wav
    * url: http://www.freesound.org/people/stamperadam/sounds/96104/
    * license: Creative Commons 0
  * 96103__stamperadam__G_2_hard.wav
    * url: http://www.freesound.org/people/stamperadam/sounds/96103/
    * license: Creative Commons 0
  * 96102__stamperadam__E5_soft.wav
    * url: http://www.freesound.org/people/stamperadam/sounds/96102/
    * license: Creative Commons 0
  * 96101__stamperadam__E5_med.wav
    * url: http://www.freesound.org/people/stamperadam/sounds/96101/
    * license: Creative Commons 0
  * 96100__stamperadam__E5_hard.wav
    * url: http://www.freesound.org/people/stamperadam/sounds/96100/
    * license: Creative Commons 0
  * 96099__stamperadam__E4_soft.wav
    * url: http://www.freesound.org/people/stamperadam/sounds/96099/
    * license: Creative Commons 0
  * 96098__stamperadam__E4_med.wav
    * url: http://www.freesound.org/people/stamperadam/sounds/96098/
    * license: Creative Commons 0
  * 96097__stamperadam__E4_hard.wav
    * url: http://www.freesound.org/people/stamperadam/sounds/96097/
    * license: Creative Commons 0
  * 96096__stamperadam__E3_soft.wav
    * url: http://www.freesound.org/people/stamperadam/sounds/96096/
    * license: Creative Commons 0
  * 96095__stamperadam__E3_med.wav
    * url: http://www.freesound.org/people/stamperadam/sounds/96095/
    * license: Creative Commons 0
  * 96094__stamperadam__E3_hard.wav
    * url: http://www.freesound.org/people/stamperadam/sounds/96094/
    * license: Creative Commons 0
  * 96093__stamperadam__C6_soft.wav
    * url: http://www.freesound.org/people/stamperadam/sounds/96093/
    * license: Creative Commons 0
  * 96092__stamperadam__C6_med.wav
    * url: http://www.freesound.org/people/stamperadam/sounds/96092/
    * license: Creative Commons 0
  * 96091__stamperadam__C6_hard.wav
    * url: http://www.freesound.org/people/stamperadam/sounds/96091/
    * license: Creative Commons 0
  * 96090__stamperadam__C5_soft.wav
    * url: http://www.freesound.org/people/stamperadam/sounds/96090/
    * license: Creative Commons 0
  * 96089__stamperadam__C5_med.wav
    * url: http://www.freesound.org/people/stamperadam/sounds/96089/
    * license: Creative Commons 0
  * 96088__stamperadam__C5_hard.wav
    * url: http://www.freesound.org/people/stamperadam/sounds/96088/
    * license: Creative Commons 0
  * 96087__stamperadam__C4_soft.wav
    * url: http://www.freesound.org/people/stamperadam/sounds/96087/
    * license: Creative Commons 0
  * 96086__stamperadam__C4_med.wav
    * url: http://www.freesound.org/people/stamperadam/sounds/96086/
    * license: Creative Commons 0
  * 96085__stamperadam__C4_hard.wav
    * url: http://www.freesound.org/people/stamperadam/sounds/96085/
    * license: Creative Commons 0
  * 96084__stamperadam__C3_soft.wav
    * url: http://www.freesound.org/people/stamperadam/sounds/96084/
    * license: Creative Commons 0
  * 96083__stamperadam__C3_med.wav
    * url: http://www.freesound.org/people/stamperadam/sounds/96083/
    * license: Creative Commons 0
  * 96082__stamperadam__C3_hard.wav
    * url: http://www.freesound.org/people/stamperadam/sounds/96082/
    * license: Creative Commons 0

